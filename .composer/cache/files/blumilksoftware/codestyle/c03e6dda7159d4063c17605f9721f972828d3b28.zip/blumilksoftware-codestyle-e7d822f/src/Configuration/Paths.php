<?php

declare(strict_types=1);

namespace Blumilk\Codestyle\Configuration;

interface Paths
{
    public function get(): array;
}
