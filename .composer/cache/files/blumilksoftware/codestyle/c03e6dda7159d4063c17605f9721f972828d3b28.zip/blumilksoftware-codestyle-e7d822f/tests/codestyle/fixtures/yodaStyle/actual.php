<?php

if (null === $a) {
    echo "null";
}

if (null == $a) {
    echo "null";
}

if (3 >= $a) {
    echo 3;
}

if (3 <= $a) {
    echo 3;
}

if (5 > $a) {
    echo 5;
}

if (null < $a) {
    echo "null";
}
