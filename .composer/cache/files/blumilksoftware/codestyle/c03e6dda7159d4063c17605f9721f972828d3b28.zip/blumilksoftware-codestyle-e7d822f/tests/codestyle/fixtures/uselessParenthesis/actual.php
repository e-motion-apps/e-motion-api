<?php

declare(strict_types=1);

if (($a === 1)) {

}
