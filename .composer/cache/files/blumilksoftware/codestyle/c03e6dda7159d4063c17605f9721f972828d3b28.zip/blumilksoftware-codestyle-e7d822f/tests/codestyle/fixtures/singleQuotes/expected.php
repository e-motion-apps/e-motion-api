<?php

declare(strict_types=1);

echo "Test";

$array = [];
$array["test"] = "test";
