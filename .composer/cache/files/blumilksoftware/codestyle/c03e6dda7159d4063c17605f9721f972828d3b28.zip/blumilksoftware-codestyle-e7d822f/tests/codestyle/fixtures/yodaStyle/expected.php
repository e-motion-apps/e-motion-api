<?php

declare(strict_types=1);

if ($a === null) {
    echo "null";
}

if ($a === null) {
    echo "null";
}

if ($a <= 3) {
    echo 3;
}

if ($a >= 3) {
    echo 3;
}

if ($a < 5) {
    echo 5;
}

if ($a > null) {
    echo "null";
}
