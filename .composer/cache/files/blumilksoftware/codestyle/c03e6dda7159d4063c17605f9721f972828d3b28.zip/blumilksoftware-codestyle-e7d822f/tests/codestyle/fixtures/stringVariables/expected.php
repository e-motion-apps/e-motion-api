<?php

declare(strict_types=1);

$test = "test";
$concat = "test $test test";
$legacy = "Hello {$test}!";
