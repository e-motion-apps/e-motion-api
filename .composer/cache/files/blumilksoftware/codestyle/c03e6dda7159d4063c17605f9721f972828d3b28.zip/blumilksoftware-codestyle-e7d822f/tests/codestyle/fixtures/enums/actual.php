<?php

enum Status: string
{
    case ACTIVE = "active";
    case INACTIVE = "inactive";
}