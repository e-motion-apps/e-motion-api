<?php

declare(strict_types=1);

$a=1+2;

$b=$a===3;

$c=$a<5;

$d=!$c;
