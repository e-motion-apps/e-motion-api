<?php

class StrictTypesExample
{
}
